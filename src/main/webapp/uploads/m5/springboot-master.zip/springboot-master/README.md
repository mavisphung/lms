# springboot

To set the Time Zone by using docker - run the below command

docker run -d -p 8080:8080 -e TZ=Asia/Calcutta --name=timezoneapp com.talk2amareswaran.projects/timezoneapp:0.0.1-SNAPSHOT
