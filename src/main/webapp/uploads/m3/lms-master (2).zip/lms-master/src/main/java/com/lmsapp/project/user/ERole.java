package com.lmsapp.project.user;

public enum ERole {
	ROLE_ADMIN,
	ROLE_STUDENT,
	ROLE_INSTRUCTOR;
}
