package com.lmsapp.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockLmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
