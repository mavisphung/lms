//$('.dropdown-toggle').dropdown();

// const changeWidth = function() {
//   const dropdownMenu = $('.btn-width');
//   const btnDropdownToggle = $('.dropdown-toggle');
//   dropdownMenu.width = btnDropdownToggle.width;
// }
// changeWidth();